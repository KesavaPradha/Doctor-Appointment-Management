package com.app.oldbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.fragment.app.FragmentActivity;

import android.os.Bundle;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;

import com.google.android.gms.maps.CameraUpdateFactory;
import com.google.android.gms.maps.GoogleMap;
import com.google.android.gms.maps.OnMapReadyCallback;
import com.google.android.gms.maps.SupportMapFragment;
import com.google.android.gms.maps.model.LatLng;
import com.google.android.gms.maps.model.MarkerOptions;

public class MapsActivity extends AppCompatActivity implements OnMapReadyCallback {

    private GoogleMap mMap;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maps);
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        SupportMapFragment mapFragment = (SupportMapFragment) getSupportFragmentManager()
                .findFragmentById(R.id.map);
        mapFragment.getMapAsync(this);
    }


    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    @Override
   /* public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        // Add a marker in Sydney and move the camera
        LatLng trichy= new LatLng(10.8155, 78.69651);
        mMap.addMarker(new MarkerOptions().position(trichy).title("Marker in trichy"));
        mMap.moveCamera(CameraUpdateFactory.newLatLng(trichy));
    }*/
    public void onMapReady(GoogleMap googleMap) {
        mMap = googleMap;

        LatLng trichy= new LatLng(10.8155, 78.69651);
        mMap.addMarker(new MarkerOptions().position(trichy).title("Marker in trichy"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(trichy, 15F));

        // Add a marker in Sydney and move the camera
        LatLng puthur= new LatLng(10.817351, 78.674632);
        mMap.addMarker(new MarkerOptions().position(puthur).title("Marker in puthur"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(puthur,15F));

        LatLng srirangam= new LatLng(10.851484, 78.703520);
        mMap.addMarker(new MarkerOptions().position(srirangam).title("Marker in trichy"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(srirangam, 15F));

        LatLng samayapuram= new LatLng(10.922578, 78.740859);
        mMap.addMarker(new MarkerOptions().position(samayapuram).title("Marker in samayapuran"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(samayapuram, 15F));

        LatLng thiruvanai_kovil= new LatLng(10.850845, 78.703050);
        mMap.addMarker(new MarkerOptions().position(thiruvanai_kovil).title("Marker in tnk"));
        mMap.moveCamera(CameraUpdateFactory.newLatLngZoom(thiruvanai_kovil, 15F));

    }
    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.map_options, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Change the map type based on the user's selection.
        switch (item.getItemId()) {
            case R.id.normal_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_NORMAL);
                return true;
            case R.id.hybrid_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_HYBRID);
                return true;
            case R.id.satellite_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_SATELLITE);
                return true;
            case R.id.terrain_map:
                mMap.setMapType(GoogleMap.MAP_TYPE_TERRAIN);
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }
}
