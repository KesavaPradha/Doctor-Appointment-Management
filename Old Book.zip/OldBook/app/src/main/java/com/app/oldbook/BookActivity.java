package com.app.oldbook;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ListView;

import com.google.android.material.floatingactionbutton.FloatingActionButton;

import java.util.ArrayList;

public class BookActivity extends AppCompatActivity {


    FloatingActionButton fab;
    ArrayList<String> name, author, publication,price;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_book);

        fab = findViewById(R.id.floatingActionButton);


        fab.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent intent = new Intent(BookActivity.this,InfoActivity.class);
                startActivity(intent);

               /* DialogBox aDialogBox = new DialogBox();
                aDialogBox.show(getSupportFragmentManager(), "dialog Box");*/

            }
        });


    }
}
