package com.app.oldbook;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Values {

    ArrayList<String> uid = new ArrayList<>();
    ArrayList<String> name = new ArrayList<>();
    ArrayList<String> mail = new ArrayList<>();
    ArrayList<String> password = new ArrayList<>();
    ArrayList<String> phone = new ArrayList<>();
    ArrayList<String> lat = new ArrayList<>();
    ArrayList<String> lon = new ArrayList<>();
    ArrayList<Map<String,String>> userbooks = new ArrayList<>();

    void initialiser(){

        uid.add("1Vs8q3L3aVZIgGEXK0Qzesf7Vv63");
        uid.add("RGXO7hicC1MnNg3O0E7JmsmN0I33");
        uid.add("ngihwS5aC6Q0iUJYDBRU9SzQy4C2");
        uid.add("y03IDG6NreOZD1GbSHjWgS7crb33");
        name.add("kesava");
        name.add("preetha");
        name.add("kavin");
        name.add("varshu");
        mail.add("kesava@gmail.com");
        mail.add("preetha@gmail.com");
        mail.add("kavin@gmail.com");
        mail.add("varshu@gmail.com");
        password.add("12345678");
        password.add("12345678");
        password.add("12345678");
        password.add("12345678");
        phone.add("9876543210");
        phone.add("9876543210");
        phone.add("9876543210");
        phone.add("9876543210");
        lat.add("@");
        lat.add("@");
        lat.add("@");
        lat.add("@");
        lon.add("@");
        lon.add("@");
        lon.add("@");
        lon.add("@");

        Map<String,String> map = new HashMap();
        map.put("Name", "Physics");
        map.put("Author", "Chithode");
        map.put("Publication", "Technical Education");
        map.put("Price","0");
        map.put("Choice","Donate");

        userbooks.add(map);

        Map<String,String> map1 = new HashMap();

        map1.put("Name", "Harry Potter");
        map1.put("Author", "J.K.Rowling");
        map1.put("Publication", "ABC Publication");
        map1.put("Price","0");
        map1.put("Choice","Exchange");

        userbooks.add(map1);
        Map<String,String> map2 = new HashMap();

        map2.put("Name", "TNPSC");
        map2.put("Author", "abc");
        map2.put("Publication", "Indian Academy");
        map2.put("Price","100");
        map2.put("Choice","Sell");

        userbooks.add(map2);
        Map<String,String> map3 = new HashMap();

        map3.put("Name", "Two States");
        map3.put("Author", "Chetan Bhagat");
        map3.put("Publication", "xyz Publication");
        map3.put("Price","0");
        map3.put("Choice","Exchange");

        userbooks.add(map3);
        Map<String,String> map4 = new HashMap();

        map4.put("Name", "Alchemist");
        map4.put("Author", "aaa");
        map4.put("Publication", "zzz publication");
        map4.put("Price","200");
        map4.put("Choice","Sell");

        userbooks.add(map4);
        Map<String,String> map5 = new HashMap();

        map5.put("Name", "Tin-Tin");
        map5.put("Author", "tin");
        map5.put("Publication", "Tin Publication");
        map5.put("Price","0");
        map5.put("Choice","Exchange");

        userbooks.add(map5);
        Map<String,String> map6 = new HashMap();

        map6.put("Name", "Neet Book");
        map6.put("Author", "doctor");
        map6.put("Publication", "Medo Publication");
        map6.put("Price","0");
        map6.put("Choice","Donate");

        userbooks.add(map6);
        Map<String,String> map7 = new HashMap();

        map7.put("Name", "Firebase Basics");
        map7.put("Author", "sara");
        map7.put("Publication", "Irony publication");
        map7.put("Price","250");
        map7.put("Choice","Sell");

        userbooks.add(map7);
        this.uid=uid;
    }

    ArrayList<String> getName(){
        return name;
    }

    ArrayList<String> getUid(){
        return uid;
    }ArrayList<String> getMail(){
        return mail;
    }ArrayList<String> getPhone(){
        return phone;
    }ArrayList<String> getPassword(){
        return password;
    }ArrayList<String> getLat(){
        return lat;
    }ArrayList<String> getLon(){
        return lon;
    }ArrayList<Map<String,String>> getUserbooks(){
        return userbooks;
    }

}
