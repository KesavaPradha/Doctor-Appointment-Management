package com.app.oldbook;

import androidx.appcompat.app.AppCompatActivity;

import android.location.Location;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ListView;
import android.widget.SimpleAdapter;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class ProfileActivity extends AppCompatActivity {


    String latitude, longitude;
    ListView aListView;
    TextView pName, pMail, pPhone, pLocation;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);

        pLocation = (TextView)findViewById(R.id.location);
        pName = (TextView)findViewById(R.id.name);
        pMail = (TextView)findViewById(R.id.email);
        pPhone = (TextView)findViewById(R.id.phoneno);

        aListView = (ListView)findViewById(R.id.listViewExample);
        Values values = new Values();
        values.initialiser();

        ArrayList<String> name = values.getName();
        ArrayList<String> uid = values.uid;
        ArrayList<String> phone = values.getPhone();
        ArrayList<String> password = values.getPassword();
        ArrayList<String> lat = values.getLat();
        ArrayList<String> lon = values.getLon();
        ArrayList<String> mail = values.getMail();
        ArrayList<Map<String, String>> books = values.getUserbooks();
        Toast.makeText(this, values.getName().get(0), Toast.LENGTH_SHORT).show();

        int i=0;
       /* for(i = 0; i < lat.size(); i++ ){

            if( lat.get(i) == latitude && lat.get(i) == longitude){

                return;

            }

        }*/

        pPhone.setText("Phone : " + phone.get(i));
        pMail.setText( "Mail-id : " + mail.get(i));
        pName.setText("Name : " + name.get(i));
        pLocation.setText("Location : " + "Trichy" );




        customSimpleAdapterListView(books,i);
    }

    private void customSimpleAdapterListView(ArrayList<Map<String,String>> books, int i)
    {



        SimpleAdapter simpleAdapter = new SimpleAdapter(this,books,R.layout.activity_profile,
                new String[]{ "Name","Author","Publication", "Choice", "Price"},new int[]{ R.id.bookTitle, R.id.bookAuthor,R.id.bookPublication,R.id.bookChoice,R.id.bookPrice});

        aListView.setAdapter(simpleAdapter);

        aListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> adapterView, View view, int i, long l) {


            }
        });

    }
}
