package com.app.oldbook;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;

public class InfoActivity extends AppCompatActivity {


    private EditText dName, dAuthor, dPublic ,dPrice;
    Button addbtn, backBtn;
    RadioGroup group;
    RadioButton radioButton;
    private DatabaseReference dDatabase;
    private String uid = "ngihwS5aC6Q0iUJYDBRU9SzQy4C2";


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_info);

        dName = (EditText)findViewById(R.id.bookNameEdt);
        dAuthor = (EditText)findViewById(R.id.bookAuthorEdt);
        dPublic = (EditText)findViewById(R.id.bookPublicEdt);
        dPrice = (EditText)findViewById(R.id.price);
        addbtn = (Button)findViewById(R.id.addBtn);
        backBtn = (Button)findViewById(R.id.backBtn);

        group = (RadioGroup)findViewById(R.id.group);


        dDatabase = FirebaseDatabase.getInstance().getReference().child("User").child(uid);

        addbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                String name = dName.getText().toString();
                String author = dAuthor.getText().toString();
                String publication = dPublic.getText().toString();
                String price = dPrice.getText().toString();

                int selectId = group.getCheckedRadioButtonId();
                radioButton = (RadioButton)findViewById(selectId);
                String choice = radioButton.getText().toString();
                Toast.makeText(InfoActivity.this, choice, Toast.LENGTH_SHORT).show();

                updateDB(name, author,publication,price,choice);



            }
        });


    }

    private void updateDB(String name, String author, String publication, String price, String choice) {

        HashMap map = new HashMap();
        map.put("author", author);
        map.put("publication", publication);
        map.put("choice",choice);
        if( choice.equals("Exchange")) {
            map.put("price", price);
        }


        dDatabase.child("books").child(name).setValue(map).addOnCompleteListener(this,new OnCompleteListener<Void>() {
            @Override
            public void onComplete(@NonNull Task<Void> task) {
                if(task.isSuccessful())
                {
                    Toast.makeText(InfoActivity.this, "Success", Toast.LENGTH_SHORT).show();
                }
                else
                {
                    Toast.makeText(InfoActivity.this, "Failed", Toast.LENGTH_SHORT).show();
                }
            }
        });


        Intent intent = new Intent(getApplicationContext(),MapsActivity.class);
        startActivity(intent);

    }
}
