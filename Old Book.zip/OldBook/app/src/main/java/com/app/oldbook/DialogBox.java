package com.app.oldbook;

import android.app.AlertDialog;
import android.app.Dialog;
import android.content.DialogInterface;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

import java.util.HashMap;
import java.util.Map;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatDialogFragment;

public class DialogBox extends AppCompatDialogFragment {


    private EditText dName, dAuthor, dPublic,dPrice;
    private FirebaseAuth dAuth;
    private DatabaseReference dDatabase;
    private String uid = "ngihwS5aC6Q0iUJYDBRU9SzQy4C2";

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);




        final AlertDialog.Builder dBuilder = new AlertDialog.Builder(getActivity());
        LayoutInflater dInflator = getActivity().getLayoutInflater();
        final View dView = dInflator.inflate(R.layout.dialog_box_activity,null);
        dBuilder.setView(dView);

        dName = dView.findViewById(R.id.bookNameEdt);
        dAuthor = dView.findViewById(R.id.bookAuthorEdt);
        dPublic = dView.findViewById(R.id.edtBookPublication);
        dPrice=dView.findViewById(R.id.price);

        dAuth = FirebaseAuth.getInstance();
        dDatabase = FirebaseDatabase.getInstance().getReference().child("User").child(uid);

        dBuilder.setView(dView).setTitle("Appointment Confirmation")
                .setNegativeButton("Cancel", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {

                    }
                }).setPositiveButton("Add", new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {

                String name = dName.getText().toString();
                String author = dAuthor.getText().toString();
                String publication = dPublic.getText().toString();
                String price=dPrice.getText().toString();

                Map map = new HashMap();
                map.put("Author",author);
                map.put("Publication",publication);
                map.put("Price",price);
                dDatabase.child("books").child(name).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                    @Override
                    public void onComplete(@NonNull Task<Void> task) {
                        if(task.isSuccessful())
                        {
                            Log.d("database_1","Success");
                        }
                        else
                        {
                            Log.d("database_1","failure");
                        }
                    }
                });


            }
        });

    }

}
