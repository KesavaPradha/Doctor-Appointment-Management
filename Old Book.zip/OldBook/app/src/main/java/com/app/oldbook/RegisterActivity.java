package com.app.oldbook;


import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;

import java.util.HashMap;
import java.util.Map;

public class RegisterActivity extends AppCompatActivity {

    private EditText mName;
    private EditText mPhone;
    private EditText mEmail;
    private EditText mPassword;
    private Button mRegister;
    private FirebaseAuth mAuth;
    private DatabaseReference mDatabase;
    private FirebaseUser user;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

       /*Intent intent = new Intent(RegisterActivity.this, BookActivity.class);
        startActivity(intent);*/


        mName = (EditText)findViewById(R.id.edtName);
        mPhone = (EditText)findViewById(R.id.edtPhone);
        mEmail = (EditText)findViewById(R.id.edtRegEmail);
        mPassword = (EditText)findViewById(R.id.edtRegPassword);
        mRegister = (Button)findViewById(R.id.btnRegister);
        mAuth = FirebaseAuth.getInstance();


        mRegister.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                String name = mName.getText().toString();
                String phone = mPhone.getText().toString();
                String email = mEmail.getText().toString();
                String password = mPassword.getText().toString();

                if( name.length() > 0 &&
                    phone.length() >0 &&
                    email.length()>0 &&
                    password.length()>6 ){

                    register( name, phone, email, password );
                    Toast.makeText(RegisterActivity.this,"data sent",Toast.LENGTH_SHORT).show();

                }else{
                    Toast.makeText(RegisterActivity.this, "Invalid data", Toast.LENGTH_SHORT).show();
                }
                Intent intent = new Intent(getApplicationContext(),BookActivity.class);
                startActivity(intent);
            }
        });

    }

    private void register(final String name, final String phone, final String email, final String password) {

        mDatabase = FirebaseDatabase.getInstance().getReference();

        mAuth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(this,new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful())
                {
                    Map map = new HashMap();
                    map.put("name", name);
                    map.put("phone", phone);
                    map.put("mail",email);
                    map.put("password", password);

                    mDatabase.child("User").child(mAuth.getCurrentUser().getUid()).setValue(map).addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            if (task.isSuccessful()){
                                Toast.makeText(RegisterActivity.this, "Login Success", Toast.LENGTH_SHORT).show();
                                Intent intent = new Intent(RegisterActivity.this, BookActivity.class);
                                startActivity(intent);
                                finish();

                            }else{

                                FirebaseUser user = FirebaseAuth.getInstance().getCurrentUser();
                                user.delete().addOnCompleteListener(new OnCompleteListener<Void>() {
                                    @Override
                                    public void onComplete(@NonNull Task<Void> task) {

                                        if( task.isSuccessful()) {
                                            Toast.makeText(getApplicationContext(), "Login Failed...Try Again", Toast.LENGTH_SHORT).show();
                                        }else {
                                            Toast.makeText(getApplicationContext(), "Server error", Toast.LENGTH_SHORT).show();
                                        }
                                    }
                                });

                            }

                        }
                    });

                }else{

                    Toast.makeText(RegisterActivity.this, "Login failed", Toast.LENGTH_SHORT).show();

                }
            }
        });
    }


}
